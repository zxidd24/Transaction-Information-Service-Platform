<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

本项目为全栈Excel处理系统，包含前端（React+Vite）和后端（Node.js+Express）。前端支持上传Excel文件，后端负责本地存储，前端可在线预览和阅读Excel内容。
